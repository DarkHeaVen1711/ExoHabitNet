# Combined Sampler Grid Report

Summary
-------
- Goal: improve detection of `HABITABLE` class (reduce cases where true HABs are predicted as NON_HABITABLE or FALSE_POSITIVE).
- What we ran: short 3-fold k‑fold experiments (2 epochs) comparing baseline and WeightedRandomSampler at several `sampler-scale` values.

Key results (3-fold, 2-epoch, focal gamma=2.0, hab-weight-multiplier=1.5)
- Baseline (no sampler): macro_f1_mean = 0.3005, hab_recall_mean = 0.8333
  - file: reports/kfold_finetune_report.json
- WeightedRandomSampler grid:
  - sampler-scale=1.0: macro_f1_mean = 0.2053, hab_recall_mean = 1.00
    - file: reports/kfold_finetune_report_scale_1.0.json
  - sampler-scale=1.5: macro_f1_mean = 0.1318, hab_recall_mean = 1.00
    - file: reports/kfold_finetune_report_scale_1.5.json
  - sampler-scale=2.0: macro_f1_mean = 0.1188, hab_recall_mean = 1.00
    - file: reports/kfold_finetune_report_scale_2.0.json
  - sampler-scale=3.0: macro_f1_mean = 0.0888, hab_recall_mean = 1.00
    - file: reports/kfold_finetune_report_scale_3.0.json

Takeaway
--------
- WeightedRandomSampler reliably increases HAB recall (we observed recall → 1.00 on these short folds), but at the cost of lowering overall macro‑F1 (more false positives / loss in precision for other classes).
- This demonstrates a recall/precision tradeoff: oversampling makes the model biased to predict `HABITABLE` more often.

Recommended next steps (prioritized)
-----------------------------------
1. Run a 5‑fold short-grid (sampler-scale × hab-weight × focal-gamma) to find the best operating point that balances HAB recall and precision. (automatable, moderate cost)
2. For the best candidate, run a threshold sweep (precision‑recall curve) and select an operating threshold that achieves a target precision/recall tradeoff instead of using 0.5 fixed probability.
3. Hard‑negative mining: collect false positives from the candidate model, add them to training (or use a double‑stage classifier) and retrain to reduce FPs.
4. Add metadata features (e.g., `quarters_available`, `cadences_total`, `nan_fraction`, `quality_flags_sum`) to the model input and run an ablation to see if metadata reduces ambiguous predictions.
5. Implement on‑the‑fly augmentation and physics‑based injection (simulate transit signals into real light curves) to expand reliable HAB examples.
6. When satisfied, run a final longer 5‑fold/full training and evaluate on the holdout; save best checkpoint and write final report.

Reproduce commands
------------------
Run a short 3‑fold smoke (example):
```bash
python -u exohabitnet/scripts/kfold_finetune.py --n-splits 3 --epochs 2 --batch-size 32 --loss focal --focal-gamma 2.0 --hab-weight-multiplier 1.5 --use-weighted-sampler --sampler-scale 1.0
```

Run the planned 5‑fold grid (example template):
```bash
python -u exohabitnet/scripts/kfold_finetune.py --n-splits 5 --epochs 4 --batch-size 32 --loss focal --focal-gamma 2.0 --hab-weight-multiplier 1.0 --use-weighted-sampler --sampler-scale 1.0
# run again with sampler-scale and hab-weight variants, collect JSON outputs
```

Notes
-----
- Small-sample HAB (n≈7) remains the root cause: many techniques help (oversampling, focal loss, injection) but synthetic/physics-based augmentation + metadata and hard-negative mining are the highest-likelihood levers to improve real-world precision while keeping recall high.

Next action
-----------
I can (A) run the 5‑fold grid now and append results, or (B) implement threshold-sweep + PR analysis on the best short-run candidate. Which should I run next?
# Combined Project Report — ExoHabitNet

This combined report aggregates preprocessing, training, and evaluation artifacts produced during Phases 1–7 and points to the canonical artifacts and reproduction commands.

**Generated:** 2026-04-07

---

## Executive Summary

- Holdout test (final evaluation file: `reports/model_performance.json`):
  - Overall accuracy: 0.6708074534161491
  - Macro F1: 0.4403761338104352
  - HABITABLE (support=2): precision=0.0, recall=0.0, f1=0.0 — unstable due to very small support

- Stratified K‑Fold (smoke run, file: `reports/kfold_finetune_report.json`):
  - n_splits: 3 (quick smoke run)
  - Macro F1 mean: 0.5335 ± 0.095
  - HAB recall mean: 0.2778 ± 0.208

- LOOCV head-only (file: `reports/loocv_cnn_head_report.json`):
  - Macro F1: 0.5758
  - HAB recall: 0.8571 (6/7 in LOOCV folds)

- Targeted HAB-samples inference (file: `reports/hab_predictions.json`):
  - n_samples: 7 (all HAB rows from `data/processed_dataset.csv`)
  - Predicted labels: 5 HABITABLE, 2 NON_HABITABLE

- Training curves (file: `reports/training_loss_summary.json`):
  - Val loss min: 0.419728 at epoch 35
  - Last recorded val loss: 0.449952

**Interpretation:** different evaluation protocols (LOOCV on encoder features, k‑fold training, and final holdout) show variance. The holdout test has only 2 HAB samples which makes HAB metrics highly unstable; LOOCV indicates the encoder carries signal for HAB detection but the final holdout split failed to include representative HAB cases.

---

## Dataset & Preprocessing (short)

- Raw samples collected: 460 FITS files (231 FALSE_POSITIVE / 222 NON_HABITABLE / 7 HABITABLE)
- Preprocessing outputs: `data/processed_dataset.csv` (460 real samples) and train/test splits
- Augmentation: HAB class augmented in-train only (dynamic target; final training CSV had HAB augmented to ~200 samples)

See `exohabitnet/PROGRESS_REPORT.md` and `exohabitnet/docs/class_imbalance_solutions.md` for full pipeline details.

---

## Modeling & Training Summary

- Architecture: `models/cnn_model.ExoHabitNetCNN` (1D-CNN)
- Training pipeline: `scripts/train.py` (supports `--pretrain`, `--loss focal`, `--focal-gamma`, `--focal-alpha`, `--hab-weight-multiplier`)
- K-fold fine-tune script: `scripts/kfold_finetune.py` (supports `--loss`, `--focal-gamma`, `--focal-alpha`, `--hab-weight-multiplier`)

Key checkpoints:

- `models/checkpoints/encoder_pretrained.pth` — encoder pretraining checkpoint (if present)
- `models/checkpoints/best_model.pth` — latest best validation model saved by `train.py`

---

## Evaluation Artifacts (paths)

- Combined/per-run JSON and figures (reports/):
  - model_performance.json — final holdout metrics
  - kfold_finetune_report.json — k-fold summary (3-split smoke run)
  - loocv_cnn_head_report.json — LOOCV on encoder features
  - training_loss_summary.json — extracted train/val loss summary
  - hab_predictions.json — predictions on all 7 HAB samples
  - `reports/hab_samples/` — per-sample PNGs (if `--plot` was used)

---

## Reproduction Commands

1. Preprocess (clean, phase-fold, split, augment train-only):
```bash
python scripts/preprocessing_pipeline.py
```

2. Optional encoder pretraining + main training (example with focal loss):
```bash
python -u scripts/train.py --pretrain --pretrain-epochs 10 --loss focal --focal-gamma 2.0 --focal-alpha 2.0 --hab-weight-multiplier 1.5 --epochs 100 --batch-size 32
```

3. Short k-fold smoke run (to reproduce kfold_finetune_report.json used here):
```bash
python -u scripts/kfold_finetune.py --loss focal --focal-gamma 2.0 --focal-alpha 2.0 --hab-weight-multiplier 1.5 --epochs 2 --n-splits 3 --batch-size 32
```

4. Evaluate final holdout & HAB samples (after training completes):
```bash
python -u scripts/evaluate.py
python -u scripts/evaluate_hab_samples.py --plot
```

---

## Recommended Next Steps

1. Run `WeightedRandomSampler` experiments in `scripts/train.py` (loader-level oversampling) and compare HAB recall on a short k-fold run.
2. Grid-search combinations of `--hab-weight-multiplier` and `--loss focal` hyperparameters (small short-fold runs then 5-fold final).
3. Collect more HAB samples (expand collection criteria or pull from other missions) — most robust fix.
4. If HAB recall remains unstable, consider ensembling or threshold tuning on probability outputs.

---

## Notes on Metric Variation

Metric differences across files exist because different experiments/checkpoints were used to produce each artifact. Use `reports/model_performance.json` as the authoritative holdout evaluation for the current `models/checkpoints/best_model.pth` file. Use k-fold and LOOCV reports to assess stability and variance.

---

If you want, I can (A) run a `WeightedRandomSampler` experiment grid and append results to this combined report, or (B) produce a PDF of this report with embedded figures.
