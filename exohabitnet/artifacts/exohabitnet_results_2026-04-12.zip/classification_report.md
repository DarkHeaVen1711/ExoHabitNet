# ExoHabitNet Final Model Evaluation Report

**Overall Status**: Tested on 161 Phase-Folded Light Curves

- **Accuracy**: 67.08%
- **Macro-F1**: 0.4404

### Class Breakdown:

| Class | Precision | Recall | F1-Score | Samples |
|-------|-----------|--------|----------|---------|
| HABITABLE | 0.0000 | 0.0000 | 0.0000 | 2 |
| NON_HABITABLE | 0.6050 | 0.9231 | 0.7310 | 78 |
| FALSE_POSITIVE | 0.8780 | 0.4444 | 0.5902 | 81 |
